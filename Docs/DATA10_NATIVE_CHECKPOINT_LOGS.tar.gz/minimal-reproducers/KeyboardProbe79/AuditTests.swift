import XCTest
@MainActor final class AuditTests: XCTestCase {
 func testPlainMultilineKeyboard() throws { try check(toolbar:false,spacer:false) }
 func testKeyboardToolbarWithoutSpacer() throws { try check(toolbar:true,spacer:false) }
 func testKeyboardToolbarWithSpacer() throws { try check(toolbar:true,spacer:true) }
 private func check(toolbar:Bool,spacer:Bool) throws {
  let app=XCUIApplication(); if toolbar { app.launchArguments.append("--toolbar") }; if spacer { app.launchArguments.append("--spacer") }; app.launch()
  let field=app.textFields["answer"]
  XCTAssertTrue(field.waitForExistence(timeout:30)); field.tap(); field.typeText("걸어요")
  XCTAssertEqual(field.value as? String,"걸어요")
  let before=XCTAttachment(screenshot:app.screenshot()); before.name="Keyboard visible"; before.lifetime = .keepAlways; add(before)
  if toolbar { app.buttons["閉じる"].tap() }
  else { app.swipeDown() }
  let submit=app.buttons["答える"]; XCTAssertTrue(submit.isHittable)
  submit.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:0.5)).tap()
  XCTAssertTrue(app.staticTexts["result"].waitForExistence(timeout:10)); XCTAssertEqual(app.staticTexts["result"].label,"걸어요")
  app.terminate()
 }
}
