import SwiftUI
struct ValueRow: View {
 @Environment(\.dynamicTypeSize) var size
 var body: some View {
  let layout = size.isAccessibilitySize ? AnyLayout(VStackLayout(alignment:.leading,spacing:8)) : AnyLayout(HStackLayout(alignment:.firstTextBaseline,spacing:16))
  layout {
   Text("教材バージョン").fixedSize(horizontal:false,vertical:true).frame(maxWidth:.infinity,alignment:.leading)
   Text("29").fixedSize(horizontal:false,vertical:true).frame(maxWidth:size.isAccessibilitySize ? .infinity : nil,alignment:.leading)
  }.font(.body).foregroundStyle(Color.primary).fixedSize(horizontal:false,vertical:true)
 }
}
@main struct AuditProbe: App {
 var body: some Scene { WindowGroup { NavigationStack {
 List {
  ForEach(0..<8) { n in Section {
   ValueRow()
   Text("復習と新しい学習は、どちらからでも始められます。途中までの学習も保存されます。").font(.footnote).foregroundStyle(Color.primary).fixedSize(horizontal:false,vertical:true)
  } header: { Text("記録 \(n)").foregroundStyle(Color.primary).fixedSize(horizontal:false,vertical:true) } }
  Text("最後の説明です。期間は現在の端末の時間帯で今日を含めて計算します。学習時間は計測していません。").font(.footnote).foregroundStyle(Color.primary).fixedSize(horizontal:false,vertical:true).accessibilityIdentifier("end")
 }.navigationTitle("記録").navigationBarTitleDisplayMode(.inline)
 } } }
}
