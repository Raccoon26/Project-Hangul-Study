import XCTest
@MainActor final class AuditTests: XCTestCase {
 func testInitialStandardSwiftUIListAudit() throws {
  continueAfterFailure = true
  let app=XCUIApplication(); app.launch()
  XCTAssertTrue(app.navigationBars["記録"].waitForExistence(timeout:30))
  let screen=XCTAttachment(screenshot:app.screenshot()); screen.lifetime = .keepAlways; add(screen)
  try app.performAccessibilityAudit { issue in
   let a=XCTAttachment(string:issue.detailedDescription+"\n"+(issue.element?.debugDescription ?? "No element")); a.lifetime = .keepAlways; self.add(a); return false
  }
  app.terminate()
 }
 func testStandardSwiftUIListAudit() throws {
  continueAfterFailure = true
  let app=XCUIApplication(); app.launch()
  XCTAssertTrue(app.navigationBars["記録"].waitForExistence(timeout:30))
  let last=app.staticTexts["end"]
  for _ in 0..<14 { if last.isHittable { break }; app.swipeUp() }
  let screen=XCTAttachment(screenshot:app.screenshot()); screen.lifetime = .keepAlways; add(screen)
  try app.performAccessibilityAudit { issue in
   let a=XCTAttachment(string:issue.detailedDescription+"\n"+(issue.element?.debugDescription ?? "No element")); a.lifetime = .keepAlways; self.add(a); return false
  }
  app.terminate()
 }
}
