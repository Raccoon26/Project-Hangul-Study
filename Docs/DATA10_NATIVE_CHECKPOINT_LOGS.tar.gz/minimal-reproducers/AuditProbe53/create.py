from pathlib import Path
import hashlib,json
r=Path(__file__).parent
objects={}
def ident(x):return hashlib.sha1(x.encode()).hexdigest()[:24].upper()
def add(k,isa,**kw):objects[ident(k)]={'isa':isa,**kw};return ident(k)
appref=add('appsource','PBXFileReference',lastKnownFileType='sourcecode.swift',path='Probe.swift',sourceTree='SOURCE_ROOT')
testref=add('testsource','PBXFileReference',lastKnownFileType='sourcecode.swift',path='AuditTests.swift',sourceTree='SOURCE_ROOT')
appbuild=add('appbuild','PBXBuildFile',fileRef=appref)
testbuild=add('testbuild','PBXBuildFile',fileRef=testref)
prod=add('appproduct','PBXFileReference',explicitFileType='wrapper.application',path='AuditProbe.app',sourceTree='BUILT_PRODUCTS_DIR')
tprod=add('testproduct','PBXFileReference',explicitFileType='wrapper.cfbundle',path='AuditProbeUITests.xctest',sourceTree='BUILT_PRODUCTS_DIR')
products=add('products','PBXGroup',children=[prod,tprod],name='Products',sourceTree='<group>')
group=add('root','PBXGroup',children=[appref,testref,products],sourceTree='<group>')
def configs(k,settings):
 cs=[add(k+c,'XCBuildConfiguration',name=c,buildSettings=settings) for c in ['Debug','Release']]
 return add(k+'configs','XCConfigurationList',buildConfigurations=cs,defaultConfigurationName='Debug',defaultConfigurationIsVisible=0)
common={'SDKROOT':'iphoneos','IPHONEOS_DEPLOYMENT_TARGET':'17.0','SWIFT_VERSION':'5.0','CODE_SIGN_STYLE':'Automatic','GENERATE_INFOPLIST_FILE':'YES','TARGETED_DEVICE_FAMILY':'1','SWIFT_OPTIMIZATION_LEVEL':'-Onone'}
def target(k,name,product,files,settings,deps,kind):
 phase=add(k+'phase','PBXSourcesBuildPhase',buildActionMask=2147483647,files=files,runOnlyForDeploymentPostprocessing=0)
 return add(k,'PBXNativeTarget',name=name,productName=name,productReference=product,productType=kind,buildPhases=[phase],buildRules=[],dependencies=deps,buildConfigurationList=configs(k,settings))
a=target('app','AuditProbe',prod,[appbuild],{'PRODUCT_NAME':'AuditProbe','PRODUCT_BUNDLE_IDENTIFIER':'com.example.HangulAuditProbe','INFOPLIST_KEY_UILaunchScreen_Generation':'YES'},[],'com.apple.product-type.application')
proxy=add('proxy','PBXContainerItemProxy',containerPortal=ident('project'),proxyType=1,remoteGlobalIDString=a,remoteInfo='AuditProbe')
dep=add('dep','PBXTargetDependency',target=a,targetProxy=proxy)
t=target('ui','AuditProbeUITests',tprod,[testbuild],{'PRODUCT_NAME':'AuditProbeUITests','PRODUCT_BUNDLE_IDENTIFIER':'com.example.HangulAuditProbeUITests','TEST_TARGET_NAME':'AuditProbe'},[dep],'com.apple.product-type.bundle.ui-testing')
p=add('project','PBXProject',attributes={'LastUpgradeCheck':'1500','TargetAttributes':{t:{'TestTargetID':a}}},buildConfigurationList=configs('project',common),compatibilityVersion='Xcode 14.0',developmentRegion='ja',knownRegions=['ja','Base'],mainGroup=group,productRefGroup=products,projectDirPath='',projectRoot='',targets=[a,t])
def enc(v):
 if isinstance(v,dict):return '{'+''.join(json.dumps(str(k))+ ' = '+enc(x)+';\n' for k,x in v.items())+'}'
 if isinstance(v,list):return '('+','.join(enc(x) for x in v)+')'
 return json.dumps(str(v))
pd=r/'AuditProbe.xcodeproj';pd.mkdir(exist_ok=True)
(pd/'project.pbxproj').write_text('// !$*UTF8*$!\n'+enc({'archiveVersion':1,'classes':{},'objectVersion':56,'objects':objects,'rootObject':p}))
s=pd/'xcshareddata/xcschemes';s.mkdir(parents=True,exist_ok=True)
def ref(i,n,b):return f'<BuildableReference BuildableIdentifier="primary" BlueprintIdentifier="{i}" BuildableName="{b}" BlueprintName="{n}" ReferencedContainer="container:AuditProbe.xcodeproj"/>'
(s/'AuditProbe.xcscheme').write_text(f'''<?xml version="1.0" encoding="UTF-8"?><Scheme version="1.3"><BuildAction buildImplicitDependencies="YES"><BuildActionEntries><BuildActionEntry buildForTesting="YES" buildForRunning="YES">{ref(a,'AuditProbe','AuditProbe.app')}</BuildActionEntry></BuildActionEntries></BuildAction><TestAction buildConfiguration="Debug"><Testables><TestableReference skipped="NO">{ref(t,'AuditProbeUITests','AuditProbeUITests.xctest')}</TestableReference></Testables></TestAction></Scheme>''')
