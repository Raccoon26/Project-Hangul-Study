import XCTest
@MainActor final class AuditTests:XCTestCase {
 func testSystemScrollViewport() throws { try check(false) }
 func testClippedSafeViewport() throws { try check(true) }
 private func check(_ bounded:Bool) throws {
  continueAfterFailure=true
  let app=XCUIApplication();if bounded {app.launchArguments=["--bounded"]};app.launch()
  XCTAssertTrue(app.navigationBars["学ぶ"].waitForExistence(timeout:30))
  let a=XCTAttachment(screenshot:app.screenshot());a.name="Initial viewport";a.lifetime = .keepAlways;add(a)
  try app.performAccessibilityAudit {issue in
   let a=XCTAttachment(string:issue.compactDescription+"\n"+issue.detailedDescription+"\n"+(issue.element?.debugDescription ?? "No element"));a.name="Unfiltered issue";a.lifetime = .keepAlways;self.add(a);return false
  }
  let end=app.buttons["活用・入力練習 11"]
  for _ in 0..<20 {
   if end.exists && end.isHittable && end.frame.maxY<=app.tabBars.firstMatch.frame.minY {break};app.swipeUp()
  }
  XCTAssertTrue(end.exists);XCTAssertTrue(end.isHittable);XCTAssertLessThanOrEqual(end.frame.maxY,app.tabBars.firstMatch.frame.minY)
  let a2=XCTAttachment(screenshot:app.screenshot());a2.name="Final reachable row";a2.lifetime = .keepAlways;add(a2)
  end.tap();XCTAssertTrue(app.staticTexts["確認できました"].waitForExistence(timeout:10));app.terminate()
 }
}
