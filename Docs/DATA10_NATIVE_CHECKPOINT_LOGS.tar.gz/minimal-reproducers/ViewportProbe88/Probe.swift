import SwiftUI
@main struct AuditProbe: App {
 var body: some Scene { WindowGroup { TabView { NavigationStack { ViewportHome() }.tabItem { Label("学ぶ",systemImage:"book") }; Text("設定").tabItem { Label("設定",systemImage:"gearshape") } }.tint(.primary) } }
}
struct ViewportHome: View {
 var body: some View {
  Group {
   if ProcessInfo.processInfo.arguments.contains("--bounded") { GeometryReader { _ in content }.clipped() }
   else { content }
  }.navigationTitle("学ぶ").navigationBarTitleDisplayMode(.inline)
 }
 private var content: some View {
  List {
   Section { Text("한국어").font(.largeTitle);Text("少しずつ、長く学ぶ").foregroundStyle(Color.primary).fixedSize(horizontal:false,vertical:true) }
   Section { Button("リスニングの続き") {}.font(.body) } header: { Text("続きから").foregroundStyle(Color.primary).fixedSize(horizontal:false,vertical:true) }
   Section {
    ForEach(0..<12) { n in NavigationLink("活用・入力練習 \(n)") { Text("確認できました").navigationTitle("詳細") }.font(.body).lineLimit(nil).fixedSize(horizontal:false,vertical:true) }
   } header: { Text("学ぶ").foregroundStyle(Color.primary).fixedSize(horizontal:false,vertical:true) }
  }.listStyle(.insetGrouped)
 }
}
