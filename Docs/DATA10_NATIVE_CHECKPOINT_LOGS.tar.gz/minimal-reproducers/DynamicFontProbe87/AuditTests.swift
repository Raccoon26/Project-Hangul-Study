import XCTest
import Darwin
@MainActor final class ActualFontResponseTests: XCTestCase {
 let app=XCUIApplication(bundleIdentifier:"com.example.HangulStudy")
 private func reveal(_ e:XCUIElement) {
  for _ in 0..<40 {
   let top=app.navigationBars.firstMatch.frame.maxY
   let tabs=app.tabBars.firstMatch
   let bottom=tabs.exists ? tabs.frame.minY : app.frame.maxY
   if e.exists && e.frame.minY>=top && e.frame.maxY<=bottom { return }
   let above=e.exists && e.frame.midY<app.frame.midY
   app.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:above ? 0.4:0.7)).press(forDuration:0.05,thenDragTo:app.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:above ? 0.7:0.4)))
  }
  XCTFail("Content must be reachable at the selected size: "+e.debugDescription)
 }
 private func capture(_ name:String) {
  let a=XCTAttachment(screenshot:app.screenshot());a.name=name;a.lifetime = .keepAlways;add(a)
 }
 override func tearDown() {
  capture("Final viewport")
  let a=XCTAttachment(string:app.debugDescription);a.name="Final AX tree";a.lifetime = .keepAlways;add(a)
  app.terminate()
 }
 func testActualHomeHeadersResumeAndValueRowsRespondToLiveMaximumType() {
  continueAfterFailure=false
  app.launch();XCTAssertTrue(app.tabBars.buttons["学ぶ"].waitForExistence(timeout:30))
  let labels=["続きから","今日の復習","現在のコース"]
  var normal:[String:Double]=[:]
  for label in labels { let e=app.staticTexts[label];XCTAssertTrue(e.exists);normal[label]=e.frame.height }
  capture("Normal Home before live size change")
  NSLog("DATA10_FONT_READY");fflush(stdout)
  let header=app.staticTexts["続きから"]
  let changed=XCTNSPredicateExpectation(predicate:NSPredicate { _,_ in header.exists && header.frame.height > normal["続きから"]!*1.2 },object:nil)
  XCTAssertEqual(XCTWaiter.wait(for:[changed],timeout:45),.completed,"Real Home header must grow when the system size changes while the app remains open")
  var maximum:[String:Double]=[:]
  for label in labels {
   let e=app.staticTexts[label];reveal(e);maximum[label]=e.frame.height
   XCTAssertGreaterThan(e.frame.height,normal[label]!*1.2,"Header must actually scale: "+label)
   capture("Maximum Home header "+label)
  }
  let resume=app.buttons["リスニングの続き"]
  XCTAssertTrue(resume.exists);reveal(resume)
  XCTAssertGreaterThan(resume.frame.height,80,"Long resume text must wrap at maximum size")
  capture("Maximum Resume button")
  let data=try! JSONSerialization.data(withJSONObject:["normal":normal,"maximum":maximum],options:[.prettyPrinted,.sortedKeys])
  let a=XCTAttachment(string:String(decoding:data,as:UTF8.self));a.name="Measured real header heights";a.lifetime = .keepAlways;add(a)
  app.tabBars.buttons["記録"].tap()
  let action=app.staticTexts.matching(NSPredicate(format:"label == %@","学習アクション")).firstMatch
  XCTAssertTrue(action.waitForExistence(timeout:10));XCTAssertGreaterThan(action.frame.height,35)
  capture("Maximum statistics labels and values")
  app.tabBars.buttons["設定"].tap()
  let setting=app.buttons.matching(NSPredicate(format:"label CONTAINS %@","新しく始める復習の量")).firstMatch
  XCTAssertTrue(setting.waitForExistence(timeout:10));reveal(setting)
  capture("Maximum settings Picker")
 }
}
