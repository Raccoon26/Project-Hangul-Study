import XCTest
@MainActor final class AuditTests: XCTestCase {
 func testInitialTabbedScrollAudit() throws { try check(bounded:false) }
 func testEndTabbedScrollAudit() throws { try check(bounded:true) }
 private func check(bounded:Bool) throws {
  continueAfterFailure = true
  let app=XCUIApplication(); app.launch()
  XCTAssertTrue(app.navigationBars["記録"].waitForExistence(timeout:30))
  if bounded { for _ in 0..<14 { if app.staticTexts["end"].isHittable { break }; app.swipeUp() } }
  let screen=XCTAttachment(screenshot:app.screenshot()); screen.lifetime = .keepAlways; add(screen)
  try app.performAccessibilityAudit { issue in
   let a=XCTAttachment(string:issue.detailedDescription+"\n"+(issue.element?.debugDescription ?? "No element")); a.lifetime = .keepAlways; self.add(a); return false
  }
  app.terminate()
 }
}
