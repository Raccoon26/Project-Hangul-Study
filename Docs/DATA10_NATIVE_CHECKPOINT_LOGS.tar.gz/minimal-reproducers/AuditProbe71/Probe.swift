import SwiftUI
@main struct AuditProbe: App {
 var body: some Scene { WindowGroup { TabView { NavigationStack {
 List {
  Section("学ぶ") {
   ForEach(0..<12) { n in
    if ProcessInfo.processInfo.arguments.contains("--explicit") {
     NavigationLink { Text("詳細") } label: {
      Text("活用・入力練習 \(n)").font(.body).lineLimit(nil).fixedSize(horizontal:false,vertical:true)
     }
    } else {
     NavigationLink("活用・入力練習 \(n)") { Text("詳細") }.font(.body).lineLimit(nil).fixedSize(horizontal:false,vertical:true)
    }
   }
  }
 }.navigationTitle("記録").navigationBarTitleDisplayMode(.inline)
 }.tabItem { Label("記録",systemImage:"chart.bar") }
 Text("設定").tabItem { Label("設定",systemImage:"gearshape") }
 }.tint(Color.primary) } }
}
