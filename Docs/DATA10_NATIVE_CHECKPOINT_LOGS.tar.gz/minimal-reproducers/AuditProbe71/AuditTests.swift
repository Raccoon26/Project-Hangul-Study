import XCTest
@MainActor final class AuditTests: XCTestCase {
 func testConvenienceLinkAudit() throws { try check(explicit:false) }
 func testExplicitTextLinkAudit() throws { try check(explicit:true) }
 private func check(explicit:Bool) throws {
  continueAfterFailure = true
  let app=XCUIApplication(); if explicit { app.launchArguments=["--explicit"] }; app.launch()
  XCTAssertTrue(app.navigationBars["記録"].waitForExistence(timeout:30))
  let a=XCTAttachment(screenshot:app.screenshot()); a.lifetime = .keepAlways; add(a)
  try app.performAccessibilityAudit { issue in
   let a=XCTAttachment(string:issue.detailedDescription+"\n"+(issue.element?.debugDescription ?? "No element")); a.lifetime = .keepAlways; self.add(a); return false
  }
  app.terminate()
 }
}
