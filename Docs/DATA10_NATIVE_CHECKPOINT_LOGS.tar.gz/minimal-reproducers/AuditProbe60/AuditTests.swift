import XCTest
@MainActor final class AuditTests: XCTestCase {
 func testDefaultTabbedListAudit() throws { try check(bounded:false) }
 func testNoScrollEdgeEffectTabbedListAudit() throws { try check(bounded:true) }
 private func check(bounded:Bool) throws {
  continueAfterFailure = true
  let app=XCUIApplication(); if bounded { app.launchArguments=["--no-edge-effect"] }; app.launch()
  XCTAssertTrue(app.navigationBars["記録"].waitForExistence(timeout:30))
  let screen=XCTAttachment(screenshot:app.screenshot()); screen.lifetime = .keepAlways; add(screen)
  try app.performAccessibilityAudit { issue in
   let a=XCTAttachment(string:issue.detailedDescription+"\n"+(issue.element?.debugDescription ?? "No element")); a.lifetime = .keepAlways; self.add(a); return false
  }
  app.terminate()
 }
}
