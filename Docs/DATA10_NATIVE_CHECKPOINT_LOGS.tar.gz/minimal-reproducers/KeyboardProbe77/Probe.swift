import SwiftUI
@main struct AuditProbe: App {
 var body: some Scene { WindowGroup { NavigationStack { InputProbe() } } }
}
struct InputProbe: View {
 @State private var answer = ""
 @State private var result = false
 @FocusState private var focused: Bool
 private var toolbar: Bool { ProcessInfo.processInfo.arguments.contains("--toolbar") }
 var body: some View {
  ScrollView {
   VStack(alignment:.leading,spacing:24) {
    Text("「걷다」を現在・丁寧にしてください。指定の形：-아요/어요/해요").font(.title3)
    TextField("韓国語で入力",text:$answer,axis:.vertical)
     .textFieldStyle(.roundedBorder).font(.title2).focused($focused)
     .autocorrectionDisabled().textInputAutocapitalization(.never)
    if result { Text(answer).accessibilityIdentifier("result") }
   }.frame(maxWidth:600,alignment:.leading).padding(24).frame(maxWidth:.infinity)
  }.safeAreaInset(edge:.bottom) {
   Button("答える") { focused = false; result = true }
    .frame(maxWidth:.infinity,minHeight:44).buttonStyle(.borderedProminent).controlSize(.large)
    .padding().background(Color(uiColor:.systemBackground))
  }.navigationTitle("活用").navigationBarTitleDisplayMode(.inline)
   .scrollDismissesKeyboard(.interactively)
   .toolbar { if toolbar { ToolbarItemGroup(placement:.keyboard) { Spacer(); Button("閉じる") { focused = false } } } }
 }
}
