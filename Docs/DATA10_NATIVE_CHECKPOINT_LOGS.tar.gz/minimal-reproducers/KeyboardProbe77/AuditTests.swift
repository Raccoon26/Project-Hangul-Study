import XCTest
@MainActor final class AuditTests: XCTestCase {
 func testPlainMultilineKeyboard() throws { try check(toolbar:false) }
 func testMultilineWithKeyboardToolbar() throws { try check(toolbar:true) }
 private func check(toolbar:Bool) throws {
  let app=XCUIApplication(); if toolbar { app.launchArguments=["--toolbar"] }; app.launch()
  let field=app.textFields["韓国語で入力"]
  XCTAssertTrue(field.waitForExistence(timeout:30)); field.tap(); field.typeText("걸어요")
  XCTAssertEqual(field.value as? String,"걸어요")
  let before=XCTAttachment(screenshot:app.screenshot()); before.name="Keyboard visible"; before.lifetime = .keepAlways; add(before)
  if toolbar { app.buttons["閉じる"].tap() }
  else { app.swipeDown() }
  let submit=app.buttons["答える"]; XCTAssertTrue(submit.isHittable)
  submit.coordinate(withNormalizedOffset:CGVector(dx:0.5,dy:0.5)).tap()
  XCTAssertTrue(app.staticTexts["result"].waitForExistence(timeout:10)); XCTAssertEqual(app.staticTexts["result"].label,"걸어요")
  app.terminate()
 }
}
