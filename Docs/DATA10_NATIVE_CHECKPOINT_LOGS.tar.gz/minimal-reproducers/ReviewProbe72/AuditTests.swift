import XCTest
/// One-off existing-due E2E on the preserved DATA10 QA Simulator. Expected
/// questions come from its real, naturally overdue SRS and Content29 read-only.
/// No launch hook, clock change, seed/reset or direct user DB write.
@MainActor final class ExistingDueReviewTests: XCTestCase {
 let app=XCUIApplication(bundleIdentifier:"com.example.HangulStudy")
 let items: [(String,String)] = [("지금은 돈이 없어요.","今はお金がありません。"),("국이 뜨거워요.","スープが熱いです。"),("오후에 비가 와요.","午後に雨が降ります。"),("식당에서 친구를 만나요.","식당에서 친구를 만나요."),("역에서 친구를 만나요.","역에서 친구를 만나요."),("어제 친구를 만났어요.","어제 친구를 만났어요."),("내일 아침에 일찍 나가야 해서 오늘은 먼저 잘게요. 설거지는 아침에 제가 할게요.","明日の朝")]
 private func tap(_ text:String,contains:Bool=false) {
  let p=NSPredicate(format:contains ? "label CONTAINS %@" : "label == %@",text)
  let b=app.buttons.matching(p).firstMatch
  for _ in 0..<16 {
   if b.exists && b.isHittable && b.frame.minY>=app.navigationBars.firstMatch.frame.maxY { break }
   app.swipeUp()
  }
  XCTAssertTrue(b.waitForExistence(timeout:10)); XCTAssertTrue(b.isEnabled)
  b.tap()
 }
 private func review() {
  XCTAssertTrue(app.tabBars.buttons["学ぶ"].waitForExistence(timeout:30))
  tap("項目 · 復習を確認",contains:true)
  XCTAssertTrue(app.navigationBars["今日の復習"].waitForExistence(timeout:10),app.debugDescription)
  tap("リスニング ",contains:true)
 }
 override func tearDown() {
  let a=XCTAttachment(screenshot:app.screenshot());a.lifetime = .keepAlways;add(a)
  let t=XCTAttachment(string:app.debugDescription);t.lifetime = .keepAlways;add(t)
  app.terminate()
 }
 func testRealOverdueListeningReviewGradesResumesAndCompletes() {
  continueAfterFailure=false
  app.launch();review()
  for (index,pair) in items.enumerated() {
   XCTAssertTrue(app.staticTexts["\(index+1) / \(items.count)"].waitForExistence(timeout:10))
   if index==0 {
    XCTAssertTrue(app.buttons["もう一度"].exists,"Successful playback saved by the interrupted run must survive reopening")
    XCTAssertTrue(app.buttons[pair.1].exists)
   } else { XCTAssertFalse(app.buttons[pair.1].exists,"Unheard review choices must remain hidden") }
   XCTAssertFalse(app.staticTexts["韓国語の原文："+pair.0].exists)
   tap(app.buttons["もう一度"].exists ? "もう一度" : "聞く")
   XCTAssertTrue(app.buttons[pair.1].waitForExistence(timeout:40))
   let ready=XCTNSPredicateExpectation(predicate:NSPredicate(format:"enabled == true"),object:app.buttons[pair.1])
   XCTAssertEqual(XCTWaiter.wait(for:[ready],timeout:40),.completed)
   tap(pair.1)
   XCTAssertTrue(app.staticTexts["✓ 正解"].waitForExistence(timeout:10))
   XCTAssertTrue(app.staticTexts["韓国語の原文："+pair.0].exists)
   if index==0 {
    app.terminate();app.launch();review()
    XCTAssertTrue(app.staticTexts["1 / \(items.count)"].waitForExistence(timeout:10))
    XCTAssertTrue(app.staticTexts["✓ 正解"].exists)
    XCTAssertTrue(app.staticTexts["韓国語の原文："+pair.0].exists)
   }
   tap("次へ")
  }
  XCTAssertTrue(app.staticTexts["練習完了"].waitForExistence(timeout:10))
  XCTAssertTrue(app.staticTexts["\(items.count) / \(items.count) 正解"].exists)
 }
}
