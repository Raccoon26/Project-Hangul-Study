import SwiftUI
@main struct AuditProbe: App {
 var body: some Scene { WindowGroup { TabView { NavigationStack { ProbeHome() }.tabItem { Label("学ぶ",systemImage:"book") }; Text("設定").tabItem { Label("設定",systemImage:"gearshape") } }.tint(.primary) } }
}
struct ProbeHome: View {
 private var explicit: Bool { ProcessInfo.processInfo.arguments.contains("--headline") }
 private var native: Bool { ProcessInfo.processInfo.arguments.contains("--native") }
 var body: some View {
  List {
   Section { Text("한국어").font(.largeTitle); Text("少しずつ、長く学ぶ").foregroundStyle(Color.primary).fixedSize(horizontal:false,vertical:true) }
   if native {
    Section("続きから") { Button("リスニングの続き") {}.font(.body) }
    Section("学ぶ") { links }
   } else {
    Section { Button("リスニングの続き") {}.font(.body) } header: { header("続きから") }
    Section { links } header: { header("学ぶ") }
   }
  }.listStyle(.insetGrouped).navigationTitle("学ぶ").navigationBarTitleDisplayMode(.inline)
 }
 @ViewBuilder private func header(_ value:String) -> some View {
  if explicit { Text(value).font(.headline).foregroundStyle(Color.primary).fixedSize(horizontal:false,vertical:true) }
  else { Text(value).foregroundStyle(Color.primary).fixedSize(horizontal:false,vertical:true) }
 }
 private var links: some View {
  ForEach(0..<12) { n in NavigationLink("活用・入力練習 \(n)") { Text("詳細") }.font(.body).lineLimit(nil).fixedSize(horizontal:false,vertical:true) }
 }
}
