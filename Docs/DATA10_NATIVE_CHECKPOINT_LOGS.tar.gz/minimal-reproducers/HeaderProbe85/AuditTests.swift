import XCTest
@MainActor final class AuditTests: XCTestCase {
 func testCustomHeaderInheritedFont() throws { try check(nil) }
 func testCustomHeaderExplicitHeadline() throws { try check("--headline") }
 func testNativeStringHeader() throws { try check("--native") }
 private func check(_ flag:String?) throws {
  continueAfterFailure=true
  let app=XCUIApplication(); if let flag { app.launchArguments=[flag] }; app.launch()
  XCTAssertTrue(app.navigationBars["学ぶ"].waitForExistence(timeout:30))
  let before=XCTAttachment(screenshot:app.screenshot());before.name="Initial viewport";before.lifetime = .keepAlways;add(before)
  try app.performAccessibilityAudit { issue in
   let a=XCTAttachment(string:issue.compactDescription+"\n"+issue.detailedDescription+"\n"+(issue.element?.debugDescription ?? "No element"));a.name="Unfiltered issue";a.lifetime = .keepAlways;self.add(a);return false
  }
  app.terminate()
 }
}
