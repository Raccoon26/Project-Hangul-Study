import XCTest
/// Existing naturally due QA vocabulary; real Production app and UI only.
/// No seed, clock change, data reset or direct database mutation.
@MainActor final class ExistingDueVocabularyTests: XCTestCase {
 let app=XCUIApplication(bundleIdentifier:"com.example.HangulStudy")
 let word="걷다"
 let meaning="歩く"
 private func tap(_ text:String,contains:Bool=false) {
  let b=app.buttons.matching(NSPredicate(format:contains ? "label CONTAINS %@" : "label == %@",text)).firstMatch
  for _ in 0..<24 {
   let top=app.navigationBars.firstMatch.exists ? app.navigationBars.firstMatch.frame.maxY : 0
   let tabs=app.tabBars.firstMatch
   let bottom=tabs.exists && tabs.isHittable ? tabs.frame.minY : app.frame.maxY
   if b.exists && b.isHittable && b.frame.minY>=top && b.frame.maxY<=bottom { break }
   app.swipeUp()
  }
  XCTAssertTrue(b.waitForExistence(timeout:10)); XCTAssertTrue(b.isHittable)
  let ready=XCTNSPredicateExpectation(predicate:NSPredicate(format:"enabled == true"),object:b)
  XCTAssertEqual(XCTWaiter.wait(for:[ready],timeout:10),.completed); b.tap()
 }
 private func enter() {
  XCTAssertTrue(app.tabBars.buttons["学ぶ"].waitForExistence(timeout:30))
  tap("短く復習",contains:true)
  XCTAssertTrue(app.staticTexts[word].waitForExistence(timeout:10))
  XCTAssertTrue(app.staticTexts["1 / 1"].exists)
 }
 override func tearDown() {
  let a=XCTAttachment(screenshot:app.screenshot());a.lifetime = .keepAlways;add(a)
  let t=XCTAttachment(string:app.debugDescription);t.lifetime = .keepAlways;add(t)
  app.terminate()
 }
 func testRealVocabularyReviewRevealColdResumeRateAndSchedule() {
  continueAfterFailure=false
  app.launch();enter()
  XCTAssertFalse(app.staticTexts[meaning].exists)
  XCTAssertFalse(app.buttons["覚えた"].exists,"Self rating must wait for meaning reveal")
  tap("意味を見る")
  XCTAssertTrue(app.staticTexts[meaning].waitForExistence(timeout:10))
  app.terminate();app.launch();enter()
  XCTAssertTrue(app.staticTexts[meaning].waitForExistence(timeout:10))
  XCTAssertFalse(app.buttons["意味を見る"].exists)
  tap("覚えた")
  XCTAssertTrue(app.staticTexts["復習完了"].waitForExistence(timeout:10))
  XCTAssertTrue(app.staticTexts["1語を確認しました"].exists)
  XCTAssertTrue(app.staticTexts["次の復習予定を保存しました。"].exists)
  app.terminate();app.launch()
  XCTAssertTrue(app.tabBars.buttons["学ぶ"].waitForExistence(timeout:30))
  XCTAssertFalse(app.buttons.matching(NSPredicate(format:"label CONTAINS %@","短く復習")).firstMatch.exists)
 }
}
