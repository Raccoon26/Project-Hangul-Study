import fcntl,subprocess,json,time
from pathlib import Path
root=Path('/tmp/hangul-data10-7')
base=['/Applications/Xcode.app/Contents/Developer/usr/bin/xcodebuild','-jobs','1','-project','HangulStudy.xcodeproj','-derivedDataPath',str(root/'DerivedData'),'-clonedSourcePackagesDirPath','/Users/shinchanhyeok/Desktop/Project-Hangul-Study/.build/data10-7/Packages26']
stages=[('resolve',['-scheme','HangulStudy','-resolvePackageDependencies']),('Debug-Simulator',['-scheme','HangulStudy','-configuration','Debug','-destination','generic/platform=iOS Simulator','CODE_SIGNING_ALLOWED=NO','ONLY_ACTIVE_ARCH=YES','build']),('Release-Simulator',['-scheme','HangulStudy','-configuration','Release','-destination','generic/platform=iOS Simulator','CODE_SIGNING_ALLOWED=NO','ONLY_ACTIVE_ARCH=YES','build']),('Release-iOS-architecture',['-scheme','HangulStudy','-configuration','Release','-destination','generic/platform=iOS','CODE_SIGNING_ALLOWED=NO','build']),('Release-UI-smoke',['-scheme','HangulStudy-DeviceUI','-configuration','Release','-destination','platform=iOS Simulator,id=2558B0F3-CEF8-4FE8-99EB-0E3EB9094115','CODE_SIGN_IDENTITY=-','CODE_SIGNING_ALLOWED=YES','ONLY_ACTIVE_ARCH=YES','-parallel-testing-enabled','NO','-collect-test-diagnostics','never','-only-testing:HangulStudyUITests/StudyJourneyTests/test11SearchSubmitDismissesKeyboardWithoutClearingResults','-resultBundlePath',str(root/'ReleaseLatest92.xcresult'),'test'])]
results=[]
with open(root/'xcode-serial.lock','w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for name,args in stages:
  with open(root/('build92-'+name+'.log'),'w') as log:
   start=time.time();code=subprocess.run(['caffeinate','-i']+base+args,stdout=log,stderr=subprocess.STDOUT).returncode
  results.append(dict(stage=name,exit=code,seconds=time.time()-start))
  (root/'build92-results.json').write_text(json.dumps(results,indent=2))
  if code:raise SystemExit(code)
 for kind in ['Release-iphonesimulator','Release-iphoneos']:
  with open(root/('build92-'+kind+'-ads.log'),'w') as log:
   code=subprocess.run(['python3','Tools/check_monetization.py','--built-info',str(root/'DerivedData/Build/Products'/kind/'HangulStudy.app/Info.plist')],stdout=log,stderr=subprocess.STDOUT).returncode
  results.append(dict(stage=kind+'-ads',exit=code))
  (root/'build92-results.json').write_text(json.dumps(results,indent=2))
  if code:raise SystemExit(code)
