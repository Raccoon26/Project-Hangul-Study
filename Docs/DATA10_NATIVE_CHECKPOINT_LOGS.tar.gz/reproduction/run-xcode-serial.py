import fcntl, subprocess, sys
with open('/tmp/hangul-data10-7/xcode-serial.lock','w') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    raise SystemExit(subprocess.run(sys.argv[1:]).returncode)
