import fcntl,subprocess
root='/tmp/hangul-data10-7/'
d='2558B0F3-CEF8-4FE8-99EB-0E3EB9094115'
with open(root+'xcode-serial.lock','w') as lock,open(root+'native-latest91.log','w') as log:
 fcntl.flock(lock,fcntl.LOCK_EX)
 cmd=['caffeinate','-i','/Applications/Xcode.app/Contents/Developer/usr/bin/xcodebuild','-jobs','1','-project','HangulStudy.xcodeproj','-scheme','HangulStudy','-configuration','Debug','-destination','platform=iOS Simulator,id='+d,'-derivedDataPath',root+'DerivedData','-clonedSourcePackagesDirPath','/Users/shinchanhyeok/Desktop/Project-Hangul-Study/.build/data10-7/Packages26','CODE_SIGN_IDENTITY=-','CODE_SIGNING_ALLOWED=YES','ONLY_ACTIVE_ARCH=YES','OTHER_SWIFT_FLAGS=$(inherited) -Xfrontend -enable-actor-data-race-checks','-parallel-testing-enabled','NO','-collect-test-diagnostics','never','-resultBundlePath',root+'NativeLatest91.xcresult','test']
 raise SystemExit(subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT).returncode)
